# Parte 2
Este repositório serve para dar host a parte 2 do exame em epoca normal.

# Descrição
A PokemonAPI é um sistema de criação de teams , pokemons, tipos e trainers de acordo com as preferencias do utilizador.

# Tecnologias
* XML
* Javascript
* NodeJS

# Framework e librarias
* Docker
* NojeJS

# Equipa Responsável
* Rafael Oliveira [@RafaelPiOliveira] (https://github.com/RafaelOPiOliveira)
* Guilherme Almeida [@Guilherme] (https://github.com/RafaelOPiOliveira)
